
#pragma once

#include <map>
#include <string>

namespace iproute2_paths
{
/// Returns the paths of executables in iproute2_paths.
inline std::map<std::string, std::string> paths()
{
    return {{"ip", "../iproute2_amd64~/bin/ip"}, {"ss", "../iproute2_amd64~/bin/ss"}, {"bridge", "../iproute2_amd64~/sbin/bridge"}, {"dcb", "../iproute2_amd64~/sbin/dcb"}, {"devlink", "../iproute2_amd64~/sbin/devlink"}, {"rtacct", "../iproute2_amd64~/sbin/rtacct"}, {"rtmon", "../iproute2_amd64~/sbin/rtmon"}, {"tc", "../iproute2_amd64~/sbin/tc"}, {"tipc", "../iproute2_amd64~/sbin/tipc"}, {"vdpa", "../iproute2_amd64~/sbin/vdpa"}, {"lnstat", "../iproute2_amd64~/usr/bin/lnstat"}, {"nstat", "../iproute2_amd64~/usr/bin/nstat"}, {"rdma", "../iproute2_amd64~/usr/bin/rdma"}, {"m_xt.so", "../iproute2_amd64~/usr/lib/tc/m_xt.so"}, {"q_atm.so", "../iproute2_amd64~/usr/lib/tc/q_atm.so"}, {"arpd", "../iproute2_amd64~/usr/sbin/arpd"}, {"genl", "../iproute2_amd64~/usr/sbin/genl"}, {"ctstat", "../iproute2_amd64~/usr/bin/ctstat"}, {"rtstat", "../iproute2_amd64~/usr/bin/rtstat"}, {"m_ipt.so", "../iproute2_amd64~/usr/lib/tc/m_ipt.so"}};
}
}

