
#pragma once

#include <map>
#include <string>

namespace libmd0_paths
{
/// Returns the paths of executables in libmd0_paths.
inline std::map<std::string, std::string> paths()
{
    return {{"libmd.so.0.0.5", "../libmd0_amd64~/usr/lib/x86_64-linux-gnu/libmd.so.0.0.5"}, {"libmd.so.0", "../libmd0_amd64~/usr/lib/x86_64-linux-gnu/libmd.so.0"}};
}
}

