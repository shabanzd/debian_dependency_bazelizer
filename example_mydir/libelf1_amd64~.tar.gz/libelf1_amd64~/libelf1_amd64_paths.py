def paths():
    "Returns a dict of ELF files mapped to their relative location in the runfiles."
    return {'libelf-0.188.so': '../libelf1_amd64~/usr/lib/x86_64-linux-gnu/libelf-0.188.so', 'libelf.so.1': '../libelf1_amd64~/usr/lib/x86_64-linux-gnu/libelf.so.1'}

