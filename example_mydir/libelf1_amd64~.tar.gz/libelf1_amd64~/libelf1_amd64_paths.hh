
#pragma once

#include <map>
#include <string>

namespace libelf1_paths
{
/// Returns the paths of executables in libelf1_paths.
inline std::map<std::string, std::string> paths()
{
    return {{"libelf-0.188.so", "../libelf1_amd64~/usr/lib/x86_64-linux-gnu/libelf-0.188.so"}, {"libelf.so.1", "../libelf1_amd64~/usr/lib/x86_64-linux-gnu/libelf.so.1"}};
}
}

