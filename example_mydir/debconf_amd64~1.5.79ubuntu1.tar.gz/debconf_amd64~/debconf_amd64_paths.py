def paths():
    "Returns a dict of ELF files mapped to their relative location in the runfiles."
    return {}

