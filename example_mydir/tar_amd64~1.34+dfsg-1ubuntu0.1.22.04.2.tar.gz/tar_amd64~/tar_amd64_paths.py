def paths():
    "Returns a dict of ELF files mapped to their relative location in the runfiles."
    return {'tar': '../tar_amd64~/bin/tar', 'rmt-tar': '../tar_amd64~/usr/sbin/rmt-tar'}

