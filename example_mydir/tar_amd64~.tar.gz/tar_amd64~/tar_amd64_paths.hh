
#pragma once

#include <map>
#include <string>

namespace tar_paths
{
/// Returns the paths of executables in tar_paths.
inline std::map<std::string, std::string> paths()
{
    return {{"tar", "../tar_amd64~/bin/tar"}, {"rmt-tar", "../tar_amd64~/usr/sbin/rmt-tar"}};
}
}

