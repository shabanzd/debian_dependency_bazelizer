def paths():
    "Returns a dict of ELF files mapped to their relative location in the runfiles."
    return {'libmnl.so.0.2.0': '../libmnl0_amd64~/usr/lib/x86_64-linux-gnu/libmnl.so.0.2.0', 'libmnl.so.0': '../libmnl0_amd64~/usr/lib/x86_64-linux-gnu/libmnl.so.0'}

