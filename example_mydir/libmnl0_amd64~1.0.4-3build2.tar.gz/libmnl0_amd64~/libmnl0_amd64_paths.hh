
#pragma once

#include <map>
#include <string>

namespace libmnl0_paths
{
/// Returns the paths of executables in libmnl0_paths.
inline std::map<std::string, std::string> paths()
{
    return {{"libmnl.so.0.2.0", "../libmnl0_amd64~/usr/lib/x86_64-linux-gnu/libmnl.so.0.2.0"}, {"libmnl.so.0", "../libmnl0_amd64~/usr/lib/x86_64-linux-gnu/libmnl.so.0"}};
}
}

