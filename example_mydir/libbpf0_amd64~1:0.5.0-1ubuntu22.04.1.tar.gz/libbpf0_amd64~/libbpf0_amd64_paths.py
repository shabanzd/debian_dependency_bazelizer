def paths():
    "Returns a dict of ELF files mapped to their relative location in the runfiles."
    return {'libbpf.so.0.5.0': '../libbpf0_amd64~/usr/lib/x86_64-linux-gnu/libbpf.so.0.5.0', 'libbpf.so.0': '../libbpf0_amd64~/usr/lib/x86_64-linux-gnu/libbpf.so.0'}

