
#pragma once

#include <map>
#include <string>

namespace libbpf0_paths
{
/// Returns the paths of executables in libbpf0_paths.
inline std::map<std::string, std::string> paths()
{
    return {{"libbpf.so.0.5.0", "../libbpf0_amd64~/usr/lib/x86_64-linux-gnu/libbpf.so.0.5.0"}, {"libbpf.so.0", "../libbpf0_amd64~/usr/lib/x86_64-linux-gnu/libbpf.so.0"}};
}
}

