
#pragma once

#include <map>
#include <string>

namespace libselinux1_paths
{
/// Returns the paths of executables in libselinux1_paths.
inline std::map<std::string, std::string> paths()
{
    return {{"libselinux.so.1", "../libselinux1_amd64~/lib/x86_64-linux-gnu/libselinux.so.1"}};
}
}

