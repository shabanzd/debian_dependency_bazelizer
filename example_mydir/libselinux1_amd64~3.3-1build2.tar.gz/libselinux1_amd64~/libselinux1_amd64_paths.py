def paths():
    "Returns a dict of ELF files mapped to their relative location in the runfiles."
    return {'libselinux.so.1': '../libselinux1_amd64~/lib/x86_64-linux-gnu/libselinux.so.1'}

