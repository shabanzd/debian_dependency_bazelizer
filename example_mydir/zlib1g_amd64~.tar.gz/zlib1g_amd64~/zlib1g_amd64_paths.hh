
#pragma once

#include <map>
#include <string>

namespace zlib1g_paths
{
/// Returns the paths of executables in zlib1g_paths.
inline std::map<std::string, std::string> paths()
{
    return {{"libz.so.1.2.11", "../zlib1g_amd64~/lib/x86_64-linux-gnu/libz.so.1.2.11"}, {"libz.so.1", "../zlib1g_amd64~/lib/x86_64-linux-gnu/libz.so.1"}};
}
}

