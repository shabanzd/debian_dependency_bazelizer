def paths():
    "Returns a dict of ELF files mapped to their relative location in the runfiles."
    return {'libz.so.1.2.11': '../zlib1g_amd64~/lib/x86_64-linux-gnu/libz.so.1.2.11', 'libz.so.1': '../zlib1g_amd64~/lib/x86_64-linux-gnu/libz.so.1'}

