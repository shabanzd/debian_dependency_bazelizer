def paths():
    "Returns a dict of ELF files mapped to their relative location in the runfiles."
    return {'libpcre2-8.so.0.10.4': '../libpcre2_8_0_amd64~/usr/lib/x86_64-linux-gnu/libpcre2-8.so.0.10.4', 'libpcre2-8.so.0': '../libpcre2_8_0_amd64~/usr/lib/x86_64-linux-gnu/libpcre2-8.so.0'}

