
#pragma once

#include <map>
#include <string>

namespace debconf_paths
{
/// Returns the paths of executables in debconf_paths.
inline std::map<std::string, std::string> paths()
{
    return };
}
}

