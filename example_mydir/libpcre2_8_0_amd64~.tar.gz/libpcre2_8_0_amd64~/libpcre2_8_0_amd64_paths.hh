
#pragma once

#include <map>
#include <string>

namespace libpcre2-8-0_paths
{
/// Returns the paths of executables in libpcre2-8-0_paths.
inline std::map<std::string, std::string> paths()
{
    return {{"libpcre2-8.so.0.10.4", "../libpcre2_8_0_amd64~/usr/lib/x86_64-linux-gnu/libpcre2-8.so.0.10.4"}, {"libpcre2-8.so.0", "../libpcre2_8_0_amd64~/usr/lib/x86_64-linux-gnu/libpcre2-8.so.0"}};
}
}

