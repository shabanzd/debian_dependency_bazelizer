def paths():
    "Returns a dict of ELF files mapped to their relative location in the runfiles."
    return {'libbsd.so.0.11.5': '../libbsd0_amd64~/usr/lib/x86_64-linux-gnu/libbsd.so.0.11.5', 'libbsd.so.0': '../libbsd0_amd64~/usr/lib/x86_64-linux-gnu/libbsd.so.0'}

