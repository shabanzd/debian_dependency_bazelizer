
#pragma once

#include <map>
#include <string>

namespace libbsd0_paths
{
/// Returns the paths of executables in libbsd0_paths.
inline std::map<std::string, std::string> paths()
{
    return {{"libbsd.so.0.11.5", "../libbsd0_amd64~/usr/lib/x86_64-linux-gnu/libbsd.so.0.11.5"}, {"libbsd.so.0", "../libbsd0_amd64~/usr/lib/x86_64-linux-gnu/libbsd.so.0"}};
}
}

