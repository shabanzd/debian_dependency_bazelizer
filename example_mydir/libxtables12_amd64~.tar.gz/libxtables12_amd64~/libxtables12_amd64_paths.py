def paths():
    "Returns a dict of ELF files mapped to their relative location in the runfiles."
    return {'libxtables.so.12.4.0': '../libxtables12_amd64~/usr/lib/x86_64-linux-gnu/libxtables.so.12.4.0', 'libxtables.so.12': '../libxtables12_amd64~/usr/lib/x86_64-linux-gnu/libxtables.so.12'}

