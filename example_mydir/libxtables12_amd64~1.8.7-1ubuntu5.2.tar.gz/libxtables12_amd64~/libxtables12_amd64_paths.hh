
#pragma once

#include <map>
#include <string>

namespace libxtables12_paths
{
/// Returns the paths of executables in libxtables12_paths.
inline std::map<std::string, std::string> paths()
{
    return {{"libxtables.so.12.4.0", "../libxtables12_amd64~/usr/lib/x86_64-linux-gnu/libxtables.so.12.4.0"}, {"libxtables.so.12", "../libxtables12_amd64~/usr/lib/x86_64-linux-gnu/libxtables.so.12"}};
}
}

