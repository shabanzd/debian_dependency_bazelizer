
#pragma once

#include <map>
#include <string>

namespace libcap2_paths
{
/// Returns the paths of executables in libcap2_paths.
inline std::map<std::string, std::string> paths()
{
    return {{"libcap.so.2.44", "../libcap2_amd64~/lib/x86_64-linux-gnu/libcap.so.2.44"}, {"libcap.so.2", "../libcap2_amd64~/lib/x86_64-linux-gnu/libcap.so.2"}};
}
}

