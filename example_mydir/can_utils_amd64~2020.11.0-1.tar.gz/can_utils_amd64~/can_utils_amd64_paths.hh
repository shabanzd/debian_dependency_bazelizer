
#pragma once

#include <map>
#include <string>

namespace can-utils_paths
{
/// Returns the paths of executables in can-utils_paths.
inline std::map<std::string, std::string> paths()
{
    return {{"asc2log", "../can_utils_amd64~/usr/bin/asc2log"}, {"bcmserver", "../can_utils_amd64~/usr/bin/bcmserver"}, {"can-calc-bit-timing", "../can_utils_amd64~/usr/bin/can-calc-bit-timing"}, {"canbusload", "../can_utils_amd64~/usr/bin/canbusload"}, {"candump", "../can_utils_amd64~/usr/bin/candump"}, {"canfdtest", "../can_utils_amd64~/usr/bin/canfdtest"}, {"cangen", "../can_utils_amd64~/usr/bin/cangen"}, {"cangw", "../can_utils_amd64~/usr/bin/cangw"}, {"canlogserver", "../can_utils_amd64~/usr/bin/canlogserver"}, {"canplayer", "../can_utils_amd64~/usr/bin/canplayer"}, {"cansend", "../can_utils_amd64~/usr/bin/cansend"}, {"cansequence", "../can_utils_amd64~/usr/bin/cansequence"}, {"cansniffer", "../can_utils_amd64~/usr/bin/cansniffer"}, {"isotpdump", "../can_utils_amd64~/usr/bin/isotpdump"}, {"isotpperf", "../can_utils_amd64~/usr/bin/isotpperf"}, {"isotprecv", "../can_utils_amd64~/usr/bin/isotprecv"}, {"isotpsend", "../can_utils_amd64~/usr/bin/isotpsend"}, {"isotpserver", "../can_utils_amd64~/usr/bin/isotpserver"}, {"isotpsniffer", "../can_utils_amd64~/usr/bin/isotpsniffer"}, {"isotptun", "../can_utils_amd64~/usr/bin/isotptun"}, {"j1939acd", "../can_utils_amd64~/usr/bin/j1939acd"}, {"j1939cat", "../can_utils_amd64~/usr/bin/j1939cat"}, {"j1939spy", "../can_utils_amd64~/usr/bin/j1939spy"}, {"j1939sr", "../can_utils_amd64~/usr/bin/j1939sr"}, {"log2asc", "../can_utils_amd64~/usr/bin/log2asc"}, {"log2long", "../can_utils_amd64~/usr/bin/log2long"}, {"slcan_attach", "../can_utils_amd64~/usr/bin/slcan_attach"}, {"slcand", "../can_utils_amd64~/usr/bin/slcand"}, {"slcanpty", "../can_utils_amd64~/usr/bin/slcanpty"}, {"testj1939", "../can_utils_amd64~/usr/bin/testj1939"}};
}
}

