def paths():
    "Returns a dict of ELF files mapped to their relative location in the runfiles."
    return {'libcap.so.2.44': '../libcap2_amd64~/lib/x86_64-linux-gnu/libcap.so.2.44', 'libcap.so.2': '../libcap2_amd64~/lib/x86_64-linux-gnu/libcap.so.2'}

